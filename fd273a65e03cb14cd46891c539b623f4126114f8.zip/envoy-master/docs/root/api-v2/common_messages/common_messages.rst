Common messages
===============

.. toctree::
  :glob:
  :maxdepth: 2

  ../api/v2/core/base.proto
  ../api/v2/core/address.proto
  ../api/v2/core/protocol.proto
  ../api/v2/discovery.proto
  ../api/v2/core/config_source.proto
  ../api/v2/core/grpc_service.proto
  ../api/v2/core/http_uri.proto
  ../api/v2/auth/cert.proto
  ../api/v2/ratelimit/ratelimit.proto
