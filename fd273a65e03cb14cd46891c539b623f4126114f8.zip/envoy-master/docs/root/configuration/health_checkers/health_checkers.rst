.. _config_health_checkers:

Health checkers
===============

.. toctree::
  :maxdepth: 2

  redis