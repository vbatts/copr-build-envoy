Overview
========

* Cluster manager :ref:`architecture overview <arch_overview_cluster_manager>`
* :ref:`v2 API reference <envoy_api_msg_config.bootstrap.v2.ClusterManager>`
