To learn about this sandbox and for instructions on how to run it please head over
to the [envoy docs](https://envoyproxy.github.io/envoy/install/sandboxes/jaeger_tracing.html)
