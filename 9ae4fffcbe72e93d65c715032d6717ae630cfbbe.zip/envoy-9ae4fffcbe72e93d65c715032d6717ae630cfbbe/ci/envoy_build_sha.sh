# If you edit the SHA here you must also edit the SHA in .circleci/config.yml.

ENVOY_BUILD_SHA=44d539cb572d04c81b62425373440c54934cf267
