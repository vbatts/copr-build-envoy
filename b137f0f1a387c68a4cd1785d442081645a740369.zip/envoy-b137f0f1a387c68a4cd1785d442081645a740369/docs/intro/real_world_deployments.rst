Real world deployments
----------------------

If you have an Envoy deployment open a PR to add yourself or :ref:`let us know <getting_help>`!

Lyft
  Envoy was initially developed for use at Lyft as the primary edge and service to service
  networking layer. Lyft's deployment is currently across thousands of hosts and processes over
  2 million requests per second at peak.
