.. _config_http_filters_cors_v1:

CORS filter
===========

Cors :ref:`configuration overview <config_http_filters_cors>`.

.. code-block:: json

  {
    "name": "cors",
    "config": {}
  }
