//= require jquery
//=require "_vendor/highlight.pack"
//=require "_vendor/waypoints"
//=require "_vendor/waypoints-sticky"
//= require anchor-js

//=require "_toc"
//=require "_docs-nav-animation"

hljs.initHighlightingOnLoad();
anchors.add('.main h2, .main h3, .main h4, .main h5, .main h6');
