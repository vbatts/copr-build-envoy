Installation
============

Currently we do not provide any pre-compiled binaries or startup scripts. Typically Envoy will be
used with the :ref:`hot restart wrapper <operations_hot_restarter>` for launching. In the future we
may provide OS specific deployment packages.
