Static envoy docs
=====================

### Installing middleman dependencies

gem install bundle --user-install
bundle install --path ~/.gem/

### Running a local middleman test server to view changes

```
bundle exec middleman server
```

## Building the static site

```
bundle exec middleman build
```
