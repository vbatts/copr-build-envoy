.. _install:

Building and installation
=========================

.. toctree::
  :maxdepth: 2

  requirements
  building
  installation
  ref_configs
  sandboxes/sandboxes.rst
  tools/tools
