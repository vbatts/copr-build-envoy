Echo
====

The echo is a trivial network filter mainly meant to demonstrate the network filter API. If
installed it will echo (write) all received data back to the connected downstream client.

.. code-block:: json

  {
    "name": "echo",
    "config": {}
  }
