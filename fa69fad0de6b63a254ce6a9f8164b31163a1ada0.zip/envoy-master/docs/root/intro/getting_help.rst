.. _getting_help:

Getting help
============

We are very interested in building a community around Envoy. Please reach out to us if you are
interested in using it and need help or want to contribute.

Please see `contact info <https://github.com/envoyproxy/envoy#contact>`_.

Reporting security vulnerabilities
----------------------------------

Please see `security contact info
<https://github.com/envoyproxy/envoy#reporting-security-vulnerabilities>`_.
