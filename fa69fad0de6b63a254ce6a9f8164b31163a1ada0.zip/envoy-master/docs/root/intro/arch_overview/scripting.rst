Scripting
=========

Envoy supports `Lua <https://www.lua.org/>`_ scripting as part of a dedicated
:ref:`HTTP filter <config_http_filters_lua>`.
