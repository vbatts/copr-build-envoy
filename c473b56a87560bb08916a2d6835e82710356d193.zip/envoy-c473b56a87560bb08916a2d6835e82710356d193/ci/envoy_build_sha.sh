# If you edit the SHA here you must also edit the SHA in .circleci/config.yml.

ENVOY_BUILD_SHA=8839608c2f4b0d7c8311361ee5c8785e543d517a
