.. _operations_runtime:

Runtime
=======

:ref:`Runtime configuration <config_runtime>` can be used to modify various server settings
without restarting Envoy. The runtime settings that are available depend on how the server is
configured. They are documented in the relevant sections of the :ref:`configuration guide <config>`.
