#pragma once

namespace Envoy {

#if __cplusplus < 201402L
#error "Your compiler does not support C++14. GCC 5+ or Clang is required."
#endif

} // Envoy
