To learn about this sandbox and for instructions on how to run it please head over
to the [envoy docs](https://lyft.github.io/envoy/docs/install/sandboxes/jaeger_tracing.html)
