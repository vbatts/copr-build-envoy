Runtime
=======

Listeners support the following runtime settings:

ssl.alt_alpn
  What % of requests use the configured :ref:`alt_alpn <config_listener_ssl_context_alt_alpn>`
  protocol string. Defaults to 0.
