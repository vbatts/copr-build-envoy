.. _common_configuration_zipkin_tracing:

How do I setup Zipkin tracing?
==============================

Refer to the :ref:`zipkin sandbox setup <install_sandboxes_zipkin_tracing>`
for an example of zipkin tracing configuration.
