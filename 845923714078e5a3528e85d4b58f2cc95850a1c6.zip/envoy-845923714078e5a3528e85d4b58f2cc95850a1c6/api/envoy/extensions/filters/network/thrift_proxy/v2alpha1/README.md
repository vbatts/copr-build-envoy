Protocol buffer definitions for the Thrift proxy.
